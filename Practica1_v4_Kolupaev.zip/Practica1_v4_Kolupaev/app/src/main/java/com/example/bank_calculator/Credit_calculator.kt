package com.example.bank_calculator

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.TooltipCompat
import android.widget.*
import kotlin.math.round

class Credit_calculator : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_calculator)

        var seekBar = findViewById<SeekBar>(R.id.credit_sum_SeekBar)
        val btnCalculate = findViewById<Button>(R.id.count_credit_button)
        var sum = findViewById<TextView>(R.id.sum)
        val backButton = findViewById<ImageButton>(R.id.back_button)


        backButton.setOnClickListener {
            val intent = Intent (this, Bank::class.java)
            startActivity(intent)
        }

        btnCalculate.setOnClickListener {
            val creditAmount = seekBar.progress

            val numEditText = findViewById<EditText>(R.id.period_of_credit_input)

            if (numEditText.text.isEmpty()) {
                Toast.makeText(this@Credit_calculator, "Введите срок кредита", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val loanTerm = numEditText.text.toString().toInt()
            if (loanTerm > 60 || loanTerm < 1){
                Toast.makeText(this@Credit_calculator, "Неверный срок кредита", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val monthlyPayment = round(calculateMonthlyPayment (creditAmount, loanTerm)*100)/100

            val intent = Intent (this, Calculation::class.java)
            intent.putExtra("monthly_payment", monthlyPayment)
            intent.putExtra("credit_amount", creditAmount)
            intent.putExtra("loan_term", loanTerm)
            startActivity(intent)
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                sum.text = seekBar.progress.toString() + " руб."
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // you can probably leave this empty
            }
            override fun onStopTrackingTouch(seekBar: SeekBar) {

            }
        })
        }

        private fun calculateMonthlyPayment(creditAmount: Int, loanTerm: Int): Double {
            return when {
                loanTerm <= 12 -> creditAmount.toDouble() / loanTerm + creditAmount * 0.059
                loanTerm in 13..24 -> {
                    val s1 = creditAmount.toDouble() / 12 + creditAmount * 0.059
                    s1 + (creditAmount - s1 * 12) * 0.051
                }
                else -> {
                    val s1 = creditAmount.toDouble() / 12 + creditAmount * 0.059
                    val n = loanTerm - 12
                    s1 + (creditAmount - s1 * 12) * 0.042 + (creditAmount - s1 * 12 - n * s1) * 0.042
                }
            }
        }

}