package com.example.bank_calculator

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Calculation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculation)

        val btnReg = findViewById<Button>(R.id.count_credit_button)
        btnReg.setOnClickListener {
            val intent = Intent (this, Bank::class.java)
            startActivity(intent)
        }

        val monthPayText = findViewById<TextView>(R.id.month_payment)
        val sumText = findViewById<TextView>(R.id.sum)
        val paymentPeriod = findViewById<TextView>(R.id.period_of_credit_input)

        val monthlyPayment = intent.getDoubleExtra("monthly_payment", 0.0)
        val sumPayment = intent.getIntExtra("credit_amount", 0)
        val loanPayment = intent.getIntExtra("loan_term", 0)

        sumText.text = "Общая сумма: $sumPayment р."
        monthPayText.text = "Месячная оплата: $monthlyPayment р."
        paymentPeriod.text = "Кол-во месяцев: $loanPayment м."
    }
}